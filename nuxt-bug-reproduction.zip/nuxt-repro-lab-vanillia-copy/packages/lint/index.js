import { defineConfig } from "eslint/config";
import { createConfigForNuxt } from "@nuxt/eslint-config";
import eslintPluginPrettierRecommended from "eslint-plugin-prettier/recommended";

// Custom
import { baseEslintIgnores } from "./constants/ignores.js";
import { baseEslintRules, baseEslintNuxtRules } from "./constants/rules.js";

// Re-export const
export { baseEslintIgnores, baseEslintRules, baseEslintNuxtRules };

// For usage within a Nuxt context
export const baseEslintNuxtConfig = defineConfig([
  eslintPluginPrettierRecommended,
  baseEslintIgnores,
  baseEslintRules,
  baseEslintNuxtRules,
]);

//  For standalone usage in packages without Nuxt context.
export const baseEslintConfig = createConfigForNuxt().append(
  eslintPluginPrettierRecommended,
  baseEslintIgnores,
  baseEslintRules
);

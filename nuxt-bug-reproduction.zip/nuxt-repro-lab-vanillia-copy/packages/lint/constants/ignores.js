import { defineConfig } from "eslint/config";

export const baseEslintIgnores = defineConfig([
  {
    ignores: [
      "**/node_modules",
      "**/.nuxt",
      "**/.output",
      "**/logs",

      "**/*.log",
      "**/.DS_Store",
      "**/*.pem",
      "**/npm-debug.log*",
      "**/.turbo",
      "**/.vercel",
      "**/.gitignore",
      "**/.env.*",
      "**/!.env.example",
    ],
  },
]);

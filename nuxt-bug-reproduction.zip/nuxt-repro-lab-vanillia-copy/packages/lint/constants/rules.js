import { defineConfig } from "eslint/config";
import turbo from "eslint-plugin-turbo";
import globals from "globals";
import TypescriptParser from "@typescript-eslint/parser";
import VueParser from "vue-eslint-parser";

// Non nuxt rules
export const baseEslintRules = defineConfig([
  {
    name: "base-eslint-rules",
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
      },
      parser: VueParser,
      parserOptions: {
        parser: TypescriptParser,
      },
    },
    plugins: {
      turbo,
    },
    files: ["**/*.ts", "**/*.vue"],
    rules: {
      // turbo
      "turbo/no-undeclared-env-vars": "error",

      // vue
      "vue/no-multiple-template-root": "warn",
      "vue/require-default-prop": "warn",

      // typescript
      "@typescript-eslint/no-empty-object-type": "off",
      "@typescript-eslint/no-unsafe-function-type": "warn",

      // other
      "no-empty": "warn",
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["../*"],
              message: "Relative imports are not allowed.",
            },
          ],
        },
      ],
    },
  },
]);

// Base rules for usage with a nuxt context
export const baseEslintNuxtRules = defineConfig([
  {
    rules: {
      "nuxt/prefer-import-meta": "error",
    },
  },
  {
    files: ["**/*.{js,ts,vue}"],
    ignores: ["plugins/**/*.{js,ts,vue}"],
    rules: {
      "no-restricted-globals": [
        "error",
        {
          name: "useToast",
          message:
            "Import 'useToast' is allowed only inside plugins! Use { $toast } = useNuxtApp()",
        },
      ],
    },
  },
]);

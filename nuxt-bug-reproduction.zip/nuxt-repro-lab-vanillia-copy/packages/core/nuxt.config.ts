import { createResolver } from "@nuxt/kit";

const { resolve } = createResolver(import.meta.url);

export default defineNuxtConfig({
  ssr: false,

  devtools: { enabled: true },
  compatibilityDate: "2025-12-23",
  typescript: {
    tsConfig: {
      include: [`${resolve("@types")}/*.d.ts`],
    },
  },
  alias: {
    "~~core": resolve(),
    "~core": resolve("app"),
  },
  modules: ["@nuxt/eslint"],
  imports: { dirs: ["models/**"] },
});

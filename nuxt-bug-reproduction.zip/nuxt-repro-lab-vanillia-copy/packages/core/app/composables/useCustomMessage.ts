export default function useCustomMessage() {
  return "This is a custom message from @pkg/core useCustomMessage composable.";
}

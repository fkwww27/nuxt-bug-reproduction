export enum EDevicePlatform {
  MOBILE = "mobile",
  DESKTOP = "desktop",
}

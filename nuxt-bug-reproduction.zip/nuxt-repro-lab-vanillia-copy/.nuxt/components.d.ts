
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const Navigation: typeof import("../app/components/Navigation.vue")['default']
export const WModal: typeof import("../app/components/WModal.vue")['default']
export const UColorModeAvatar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeAvatar.vue")['default']
export const UColorModeButton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeButton.vue")['default']
export const UColorModeImage: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeImage.vue")['default']
export const UColorModeSelect: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeSelect.vue")['default']
export const UColorModeSwitch: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeSwitch.vue")['default']
export const UAccordion: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Accordion.vue")['default']
export const UAlert: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Alert.vue")['default']
export const UApp: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/App.vue")['default']
export const UAuthForm: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/AuthForm.vue")['default']
export const UAvatar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Avatar.vue")['default']
export const UAvatarGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/AvatarGroup.vue")['default']
export const UBadge: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Badge.vue")['default']
export const UBanner: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Banner.vue")['default']
export const UBlogPost: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/BlogPost.vue")['default']
export const UBlogPosts: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/BlogPosts.vue")['default']
export const UBreadcrumb: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Breadcrumb.vue")['default']
export const UButton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Button.vue")['default']
export const UCalendar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Calendar.vue")['default']
export const UCard: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Card.vue")['default']
export const UCarousel: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Carousel.vue")['default']
export const UChangelogVersion: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChangelogVersion.vue")['default']
export const UChangelogVersions: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChangelogVersions.vue")['default']
export const UChatMessage: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatMessage.vue")['default']
export const UChatMessages: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatMessages.vue")['default']
export const UChatPalette: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPalette.vue")['default']
export const UChatPrompt: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPrompt.vue")['default']
export const UChatPromptSubmit: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPromptSubmit.vue")['default']
export const UChatReasoning: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatReasoning.vue")['default']
export const UChatShimmer: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatShimmer.vue")['default']
export const UChatTool: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatTool.vue")['default']
export const UCheckbox: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Checkbox.vue")['default']
export const UCheckboxGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/CheckboxGroup.vue")['default']
export const UChip: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Chip.vue")['default']
export const UCollapsible: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Collapsible.vue")['default']
export const UColorPicker: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ColorPicker.vue")['default']
export const UCommandPalette: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/CommandPalette.vue")['default']
export const UContainer: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Container.vue")['default']
export const UContextMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ContextMenu.vue")['default']
export const UContextMenuContent: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ContextMenuContent.vue")['default']
export const UDashboardGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardGroup.vue")['default']
export const UDashboardNavbar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardNavbar.vue")['default']
export const UDashboardPanel: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardPanel.vue")['default']
export const UDashboardResizeHandle: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardResizeHandle.vue")['default']
export const UDashboardSearch: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSearch.vue")['default']
export const UDashboardSearchButton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSearchButton.vue")['default']
export const UDashboardSidebar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebar.vue")['default']
export const UDashboardSidebarCollapse: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebarCollapse.vue")['default']
export const UDashboardSidebarToggle: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebarToggle.vue")['default']
export const UDashboardToolbar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardToolbar.vue")['default']
export const UDrawer: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Drawer.vue")['default']
export const UDropdownMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DropdownMenu.vue")['default']
export const UDropdownMenuContent: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DropdownMenuContent.vue")['default']
export const UEditor: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Editor.vue")['default']
export const UEditorDragHandle: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorDragHandle.vue")['default']
export const UEditorEmojiMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorEmojiMenu.vue")['default']
export const UEditorMentionMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorMentionMenu.vue")['default']
export const UEditorSuggestionMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorSuggestionMenu.vue")['default']
export const UEditorToolbar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorToolbar.vue")['default']
export const UEmpty: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Empty.vue")['default']
export const UError: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Error.vue")['default']
export const UFieldGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FieldGroup.vue")['default']
export const UFileUpload: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FileUpload.vue")['default']
export const UFooter: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Footer.vue")['default']
export const UFooterColumns: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FooterColumns.vue")['default']
export const UForm: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Form.vue")['default']
export const UFormField: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FormField.vue")['default']
export const UHeader: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Header.vue")['default']
export const UIcon: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Icon.vue")['default']
export const UInput: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Input.vue")['default']
export const UInputDate: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputDate.vue")['default']
export const UInputMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputMenu.vue")['default']
export const UInputNumber: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputNumber.vue")['default']
export const UInputRating: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputRating.vue")['default']
export const UInputTags: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputTags.vue")['default']
export const UInputTime: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputTime.vue")['default']
export const UKbd: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Kbd.vue")['default']
export const ULink: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Link.vue")['default']
export const ULinkBase: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/LinkBase.vue")['default']
export const UListbox: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Listbox.vue")['default']
export const UMain: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Main.vue")['default']
export const UMarquee: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Marquee.vue")['default']
export const UModal: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Modal.vue")['default']
export const UNavigationMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/NavigationMenu.vue")['default']
export const UOverlayProvider: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/OverlayProvider.vue")['default']
export const UPage: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Page.vue")['default']
export const UPageAnchors: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageAnchors.vue")['default']
export const UPageAside: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageAside.vue")['default']
export const UPageBody: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageBody.vue")['default']
export const UPageCTA: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageCTA.vue")['default']
export const UPageCard: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageCard.vue")['default']
export const UPageColumns: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageColumns.vue")['default']
export const UPageFeature: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageFeature.vue")['default']
export const UPageGrid: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageGrid.vue")['default']
export const UPageHeader: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageHeader.vue")['default']
export const UPageHero: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageHero.vue")['default']
export const UPageLinks: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageLinks.vue")['default']
export const UPageList: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageList.vue")['default']
export const UPageLogos: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageLogos.vue")['default']
export const UPageSection: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageSection.vue")['default']
export const UPagination: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Pagination.vue")['default']
export const UPinInput: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PinInput.vue")['default']
export const UPopover: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Popover.vue")['default']
export const UPricingPlan: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingPlan.vue")['default']
export const UPricingPlans: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingPlans.vue")['default']
export const UPricingTable: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingTable.vue")['default']
export const UProgress: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Progress.vue")['default']
export const UProgressGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ProgressGroup.vue")['default']
export const URadioGroup: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/RadioGroup.vue")['default']
export const UScrollArea: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ScrollArea.vue")['default']
export const USelect: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Select.vue")['default']
export const USelectMenu: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/SelectMenu.vue")['default']
export const USeparator: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Separator.vue")['default']
export const USidebar: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Sidebar.vue")['default']
export const USkeleton: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Skeleton.vue")['default']
export const USlideover: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Slideover.vue")['default']
export const USlider: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Slider.vue")['default']
export const USplitter: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Splitter.vue")['default']
export const UStepper: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Stepper.vue")['default']
export const USwitch: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Switch.vue")['default']
export const UTable: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Table.vue")['default']
export const UTabs: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tabs.vue")['default']
export const UTextarea: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Textarea.vue")['default']
export const UTheme: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Theme.vue")['default']
export const UTimeline: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Timeline.vue")['default']
export const UToast: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Toast.vue")['default']
export const UToaster: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Toaster.vue")['default']
export const UTooltip: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tooltip.vue")['default']
export const UTree: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tree.vue")['default']
export const UUser: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/User.vue")['default']
export const ULocaleSelect: typeof import("../node_modules/@nuxt/ui/dist/runtime/components/locale/LocaleSelect.vue")['default']
/**
 * Displays the welcome screen used by new Nuxt projects.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-welcome
 */
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
/**
 * Renders the selected layout around pages or error content.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-layout
 */
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
/**
 * Catches client-side errors from its default slot and renders an error slot.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-error-boundary
 */
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
/**
 * Renders its default slot only on the client, with an optional server fallback.
 *
 * @see https://nuxt.com/docs/4.x/api/components/client-only
 */
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
/**
 * Renders its content only during development.
 *
 * @see https://nuxt.com/docs/4.x/api/components/dev-only
 */
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
/**
 * A drop-in replacement for Vue Router's `<RouterLink>` and the HTML `<a>` element.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-link
 */
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
/**
 * Displays a progress bar during page navigation.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-loading-indicator
 */
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
/**
 * Formats dates and times consistently across server and client using the user's locale.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-time
 */
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
/**
 * Announces route changes to assistive technologies using the current page title.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-route-announcer
 */
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
/**
 * Announces dynamic content changes to assistive technologies.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-announcer
 */
export const NuxtAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']
/**
 * Renders an optimized image through the Nuxt Image module.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-img
 */
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
/**
 * Renders responsive optimized images through the Nuxt Image module.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-picture
 */
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const Icon: typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']
/**
 * Renders the current page from the `pages/` directory.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-page
 */
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const ColorScheme: typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue")['default']
/**
 * Renders a non-interactive server component without shipping client-side JavaScript.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-island
 */
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyNavigation: LazyComponent<typeof import("../app/components/Navigation.vue")['default']>
export const LazyWModal: LazyComponent<typeof import("../app/components/WModal.vue")['default']>
export const LazyUColorModeAvatar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeAvatar.vue")['default']>
export const LazyUColorModeButton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeButton.vue")['default']>
export const LazyUColorModeImage: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeImage.vue")['default']>
export const LazyUColorModeSelect: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeSelect.vue")['default']>
export const LazyUColorModeSwitch: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/color-mode/ColorModeSwitch.vue")['default']>
export const LazyUAccordion: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Accordion.vue")['default']>
export const LazyUAlert: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Alert.vue")['default']>
export const LazyUApp: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/App.vue")['default']>
export const LazyUAuthForm: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/AuthForm.vue")['default']>
export const LazyUAvatar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Avatar.vue")['default']>
export const LazyUAvatarGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/AvatarGroup.vue")['default']>
export const LazyUBadge: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Badge.vue")['default']>
export const LazyUBanner: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Banner.vue")['default']>
export const LazyUBlogPost: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/BlogPost.vue")['default']>
export const LazyUBlogPosts: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/BlogPosts.vue")['default']>
export const LazyUBreadcrumb: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Breadcrumb.vue")['default']>
export const LazyUButton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Button.vue")['default']>
export const LazyUCalendar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Calendar.vue")['default']>
export const LazyUCard: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Card.vue")['default']>
export const LazyUCarousel: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Carousel.vue")['default']>
export const LazyUChangelogVersion: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChangelogVersion.vue")['default']>
export const LazyUChangelogVersions: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChangelogVersions.vue")['default']>
export const LazyUChatMessage: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatMessage.vue")['default']>
export const LazyUChatMessages: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatMessages.vue")['default']>
export const LazyUChatPalette: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPalette.vue")['default']>
export const LazyUChatPrompt: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPrompt.vue")['default']>
export const LazyUChatPromptSubmit: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatPromptSubmit.vue")['default']>
export const LazyUChatReasoning: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatReasoning.vue")['default']>
export const LazyUChatShimmer: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatShimmer.vue")['default']>
export const LazyUChatTool: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ChatTool.vue")['default']>
export const LazyUCheckbox: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Checkbox.vue")['default']>
export const LazyUCheckboxGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/CheckboxGroup.vue")['default']>
export const LazyUChip: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Chip.vue")['default']>
export const LazyUCollapsible: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Collapsible.vue")['default']>
export const LazyUColorPicker: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ColorPicker.vue")['default']>
export const LazyUCommandPalette: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/CommandPalette.vue")['default']>
export const LazyUContainer: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Container.vue")['default']>
export const LazyUContextMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ContextMenu.vue")['default']>
export const LazyUContextMenuContent: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ContextMenuContent.vue")['default']>
export const LazyUDashboardGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardGroup.vue")['default']>
export const LazyUDashboardNavbar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardNavbar.vue")['default']>
export const LazyUDashboardPanel: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardPanel.vue")['default']>
export const LazyUDashboardResizeHandle: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardResizeHandle.vue")['default']>
export const LazyUDashboardSearch: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSearch.vue")['default']>
export const LazyUDashboardSearchButton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSearchButton.vue")['default']>
export const LazyUDashboardSidebar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebar.vue")['default']>
export const LazyUDashboardSidebarCollapse: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebarCollapse.vue")['default']>
export const LazyUDashboardSidebarToggle: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardSidebarToggle.vue")['default']>
export const LazyUDashboardToolbar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DashboardToolbar.vue")['default']>
export const LazyUDrawer: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Drawer.vue")['default']>
export const LazyUDropdownMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DropdownMenu.vue")['default']>
export const LazyUDropdownMenuContent: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/DropdownMenuContent.vue")['default']>
export const LazyUEditor: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Editor.vue")['default']>
export const LazyUEditorDragHandle: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorDragHandle.vue")['default']>
export const LazyUEditorEmojiMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorEmojiMenu.vue")['default']>
export const LazyUEditorMentionMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorMentionMenu.vue")['default']>
export const LazyUEditorSuggestionMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorSuggestionMenu.vue")['default']>
export const LazyUEditorToolbar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/EditorToolbar.vue")['default']>
export const LazyUEmpty: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Empty.vue")['default']>
export const LazyUError: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Error.vue")['default']>
export const LazyUFieldGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FieldGroup.vue")['default']>
export const LazyUFileUpload: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FileUpload.vue")['default']>
export const LazyUFooter: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Footer.vue")['default']>
export const LazyUFooterColumns: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FooterColumns.vue")['default']>
export const LazyUForm: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Form.vue")['default']>
export const LazyUFormField: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/FormField.vue")['default']>
export const LazyUHeader: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Header.vue")['default']>
export const LazyUIcon: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Icon.vue")['default']>
export const LazyUInput: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Input.vue")['default']>
export const LazyUInputDate: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputDate.vue")['default']>
export const LazyUInputMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputMenu.vue")['default']>
export const LazyUInputNumber: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputNumber.vue")['default']>
export const LazyUInputRating: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputRating.vue")['default']>
export const LazyUInputTags: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputTags.vue")['default']>
export const LazyUInputTime: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/InputTime.vue")['default']>
export const LazyUKbd: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Kbd.vue")['default']>
export const LazyULink: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Link.vue")['default']>
export const LazyULinkBase: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/LinkBase.vue")['default']>
export const LazyUListbox: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Listbox.vue")['default']>
export const LazyUMain: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Main.vue")['default']>
export const LazyUMarquee: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Marquee.vue")['default']>
export const LazyUModal: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Modal.vue")['default']>
export const LazyUNavigationMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/NavigationMenu.vue")['default']>
export const LazyUOverlayProvider: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/OverlayProvider.vue")['default']>
export const LazyUPage: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Page.vue")['default']>
export const LazyUPageAnchors: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageAnchors.vue")['default']>
export const LazyUPageAside: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageAside.vue")['default']>
export const LazyUPageBody: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageBody.vue")['default']>
export const LazyUPageCTA: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageCTA.vue")['default']>
export const LazyUPageCard: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageCard.vue")['default']>
export const LazyUPageColumns: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageColumns.vue")['default']>
export const LazyUPageFeature: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageFeature.vue")['default']>
export const LazyUPageGrid: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageGrid.vue")['default']>
export const LazyUPageHeader: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageHeader.vue")['default']>
export const LazyUPageHero: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageHero.vue")['default']>
export const LazyUPageLinks: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageLinks.vue")['default']>
export const LazyUPageList: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageList.vue")['default']>
export const LazyUPageLogos: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageLogos.vue")['default']>
export const LazyUPageSection: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PageSection.vue")['default']>
export const LazyUPagination: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Pagination.vue")['default']>
export const LazyUPinInput: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PinInput.vue")['default']>
export const LazyUPopover: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Popover.vue")['default']>
export const LazyUPricingPlan: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingPlan.vue")['default']>
export const LazyUPricingPlans: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingPlans.vue")['default']>
export const LazyUPricingTable: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/PricingTable.vue")['default']>
export const LazyUProgress: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Progress.vue")['default']>
export const LazyUProgressGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ProgressGroup.vue")['default']>
export const LazyURadioGroup: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/RadioGroup.vue")['default']>
export const LazyUScrollArea: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/ScrollArea.vue")['default']>
export const LazyUSelect: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Select.vue")['default']>
export const LazyUSelectMenu: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/SelectMenu.vue")['default']>
export const LazyUSeparator: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Separator.vue")['default']>
export const LazyUSidebar: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Sidebar.vue")['default']>
export const LazyUSkeleton: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Skeleton.vue")['default']>
export const LazyUSlideover: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Slideover.vue")['default']>
export const LazyUSlider: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Slider.vue")['default']>
export const LazyUSplitter: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Splitter.vue")['default']>
export const LazyUStepper: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Stepper.vue")['default']>
export const LazyUSwitch: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Switch.vue")['default']>
export const LazyUTable: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Table.vue")['default']>
export const LazyUTabs: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tabs.vue")['default']>
export const LazyUTextarea: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Textarea.vue")['default']>
export const LazyUTheme: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Theme.vue")['default']>
export const LazyUTimeline: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Timeline.vue")['default']>
export const LazyUToast: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Toast.vue")['default']>
export const LazyUToaster: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Toaster.vue")['default']>
export const LazyUTooltip: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tooltip.vue")['default']>
export const LazyUTree: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/Tree.vue")['default']>
export const LazyUUser: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/User.vue")['default']>
export const LazyULocaleSelect: LazyComponent<typeof import("../node_modules/@nuxt/ui/dist/runtime/components/locale/LocaleSelect.vue")['default']>
/**
 * Lazy-loaded version of `<NuxtWelcome>`.
 *
 * Displays the welcome screen used by new Nuxt projects.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-welcome
 */
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
/**
 * Lazy-loaded version of `<NuxtLayout>`.
 *
 * Renders the selected layout around pages or error content.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-layout
 */
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
/**
 * Lazy-loaded version of `<NuxtErrorBoundary>`.
 *
 * Catches client-side errors from its default slot and renders an error slot.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-error-boundary
 */
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
/**
 * Lazy-loaded version of `<ClientOnly>`.
 *
 * Renders its default slot only on the client, with an optional server fallback.
 *
 * @see https://nuxt.com/docs/4.x/api/components/client-only
 */
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
/**
 * Lazy-loaded version of `<DevOnly>`.
 *
 * Renders its content only during development.
 *
 * @see https://nuxt.com/docs/4.x/api/components/dev-only
 */
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
/**
 * Lazy-loaded version of `<NuxtLink>`.
 *
 * A drop-in replacement for Vue Router's `<RouterLink>` and the HTML `<a>` element.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-link
 */
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
/**
 * Lazy-loaded version of `<NuxtLoadingIndicator>`.
 *
 * Displays a progress bar during page navigation.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-loading-indicator
 */
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
/**
 * Lazy-loaded version of `<NuxtTime>`.
 *
 * Formats dates and times consistently across server and client using the user's locale.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-time
 */
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
/**
 * Lazy-loaded version of `<NuxtRouteAnnouncer>`.
 *
 * Announces route changes to assistive technologies using the current page title.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-route-announcer
 */
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
/**
 * Lazy-loaded version of `<NuxtAnnouncer>`.
 *
 * Announces dynamic content changes to assistive technologies.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-announcer
 */
export const LazyNuxtAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-announcer")['default']>
/**
 * Lazy-loaded version of `<NuxtImg>`.
 *
 * Renders an optimized image through the Nuxt Image module.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-img
 */
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
/**
 * Lazy-loaded version of `<NuxtPicture>`.
 *
 * Renders responsive optimized images through the Nuxt Image module.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-picture
 */
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyIcon: LazyComponent<typeof import("../node_modules/@nuxt/icon/dist/runtime/components/index")['default']>
/**
 * Lazy-loaded version of `<NuxtPage>`.
 *
 * Renders the current page from the `pages/` directory.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-page
 */
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/@nuxtjs/color-mode/dist/runtime/component.vue")['default']>
/**
 * Lazy-loaded version of `<NuxtIsland>`.
 *
 * Renders a non-interactive server component without shipping client-side JavaScript.
 *
 * @see https://nuxt.com/docs/4.x/api/components/nuxt-island
 */
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]

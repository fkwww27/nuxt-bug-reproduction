declare module "nuxt/schema" {
  // interface AppConfig {}
  interface AppConfigInput {}
}

export {};

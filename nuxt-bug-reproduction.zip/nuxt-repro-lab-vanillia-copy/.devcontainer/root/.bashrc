source /usr/share/bash-completion/completions/git
source <(npm completion)

# Apps
alias start='npm run dev' 
alias app1='npm run dev:app1'
alias app2='npm run dev:app2'
 
# Project utilities
alias postinstall='npm run postinstall'
alias test='npm run test'
alias typecheck='npm run typecheck'
alias lint='npm run lint'
alias clear_modules='
  find . -name node_modules -type d -prune -exec rm -rf {} + &&
  rm -rf .turbo .nuxt .output dist build coverage .cache &&
  find . -type d \( -name .nuxt -o -name .output -o -name dist -o -name build \) -prune -exec rm -rf {} +
'

# GIT
alias wip='git add . && git commit -am "wip"'

ps axf | grep npm | grep -v grep | awk '{print "kill -9 " $1}'
git-wip && git push


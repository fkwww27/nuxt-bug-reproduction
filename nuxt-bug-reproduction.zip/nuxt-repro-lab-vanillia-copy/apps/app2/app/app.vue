<script lang="ts"></script>
<script setup lang="ts">
  useHead({
    title: "App 2",
  });

  const message = useCustomMessage();
</script>

<template>
  <div class="w-1/2 flex flex-col">
    <h1>app2</h1>
    <span>{{ message }}</span>
    <WButton>Custom button from @nuxt/ui</WButton>
  </div>
</template>

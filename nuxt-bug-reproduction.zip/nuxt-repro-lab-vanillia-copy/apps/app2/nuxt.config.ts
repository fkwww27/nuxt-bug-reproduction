import { createResolver } from "@nuxt/kit";

const { resolve } = createResolver(import.meta.url);

export default defineNuxtConfig({
  ssr: false,
  extends: [["@app/app1", { install: true }]],

  alias: {
    "~~app2": resolve(),
    "~app2": resolve("app"),
  },
});

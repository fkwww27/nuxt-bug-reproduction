<script lang="ts"></script>
<script setup lang="ts">
  useHead({
    title: "App 1",
  });

  const message = useCustomMessage();
</script>

<template>
  <div class="w-1/2 flex flex-col">
    <h1>{{ EDevicePlatform.DESKTOP }} app1</h1>
    <span>{{ message }}</span>
    <WButton>Custom button from @nuxt/ui</WButton>
  </div>
</template>

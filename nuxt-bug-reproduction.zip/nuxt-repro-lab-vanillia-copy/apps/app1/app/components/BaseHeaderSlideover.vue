<script lang="ts">
  import type { SlideoverProps, SlideoverSlots } from "@nuxt/ui";
  import type { VNodeChild } from "vue";
  import { cn } from "tailwind-variants";

  export interface IBaseHeaderSlideoverProps extends SlideoverProps {
    class?: ClassNameValue;
    icon?: string;
    ui?: SlideoverProps["ui"] & {
      button?: string;
      title?: string;
    };
    title?: string;
  }

  export interface IBaseHeaderSlideoverEmits {
    (e: "update:open", value: boolean): void;
  }

  export interface IBaseHeaderSlideoverSlots extends SlideoverSlots {
    activator?: () => VNodeChild;
  }

  const BASE_UI = {
    overlay: "bg-grey-900/50",
    content: "divide-y divide-muted sm:ring ring-muted shadow-0 z-1 max-w-125 w-full",
    close: "cursor-pointer",
    header: "border-0 sm:pt-6 sm:pr-3 sm:pl-4 bg-elevated rounded-b-2xl overflow-hidden",
    body: "border-0 sm:py-0 sm:pb-0 sm:pr-3 sm:pl-4",
    footer: "sm:pr-3 sm:pl-4",
    // Custom
    title: "text-xl text-primary font-bold  select-none",
    button: "lg:w-12 w-10 lg:h-12 h-10 cursor-pointer",
  };
</script>

<script setup lang="ts">
  const props = withDefaults(defineProps<IBaseHeaderSlideoverProps>(), {
    class: undefined,
    ui: undefined,
    icon: "mdi-folder",
    title: undefined,
    overlay: true,
    modal: false,
    close: true,
    portal: false,

    closeIcon: "mdi-close",
    transition: true,
  });

  const open = ref(false);

  defineSlots<IBaseHeaderSlideoverSlots>();

  defineExpose({
    open: open,
    close: () => (open.value = false),
  });

  const wui = computed(() => ({
    body: cn(BASE_UI.body, props.ui?.body),
    content: cn(BASE_UI.content, props.ui?.content),
    footer: cn(BASE_UI.footer, props.ui?.footer),
    header: cn(BASE_UI.header, props.ui?.header),
    overlay: cn(BASE_UI.overlay, props.ui?.overlay),
    close: cn(BASE_UI.close, props.ui?.close),

    // custom

    title: [BASE_UI.title, props.ui?.title],
    button: [BASE_UI.button, props.ui?.button],
  }));
</script>

<template>
  <USlideover
    v-bind="props"
    :content="{
      onOpenAutoFocus: (event) => event.preventDefault(),
    }"
    :open="open"
    :ui="wui"
    @update:open="open = $event"
  >
    <slot name="activator">
      <UButton
        :icon="props.icon"
        color="primary"
        variant="soft"
        :ui="{
          base: wui.button,
          leadingIcon: 'w-6 h-6 m-auto',
        }"
      />
    </slot>

    <template #header="{ close }">
      <slot name="header" :close></slot>
    </template>

    <template #body>
      <slot :open="open" />
    </template>

    <template #footer="{ close }">
      <slot name="footer" :close></slot>
    </template>
  </USlideover>
</template>

import withNuxt from "./.nuxt/eslint.config.mjs";
import { baseEslintNuxtConfig } from "@pkg/lint";

export default withNuxt(baseEslintNuxtConfig);

import { createResolver } from "@nuxt/kit";

const { resolve } = createResolver(import.meta.url);

export default defineNuxtConfig({
  ssr: false,
  experimental: {
    viteEnvironmentApi: true,
  },
  vite: {
    optimizeDeps: {
      include: ["@vue/devtools-core", "@vue/devtools-kit"],
    },
  },
  extends: [
    ["@pkg/ui", { install: true }],
    ["@pkg/core", { install: true }],
  ],

  alias: {
    "~~app1": resolve(),
    "~app1": resolve("app"),
  },
});
